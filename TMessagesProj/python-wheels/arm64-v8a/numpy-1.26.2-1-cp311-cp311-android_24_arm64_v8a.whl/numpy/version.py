
version = "1.26.2"
__version__ = version
full_version = version

git_revision = "f004380e16445b7ac935dfc69ada1a772e0804e0"
release = 'dev' not in version and '+' not in version
short_version = version.split("+")[0]
